import React from "react";
import axios from "axios";

export default class Welcome extends React.Component {
  state = { navneListe: [] };

  componentDidMount = e => {
    this.print("søkEtter", "brukere", "Fornavn", "Chris", "");
  };

  renderArray = () => {
    if (this.state.navneListe.length > 0) {
      return this.state.navneListe.forEach(item => {
        return (
          <p key={item.Bnr}>
            {item.Fornavn}, {item.Email}
          </p>
        );
      });
    } else return <p>Ingen treff!</p>;
  };

  print(funksjonsnavn, tabell, kollonen, verdien, where) {
    axios({
      method: "get",
      url: "http://localhost/basic.php",
      params: {
        funksjonsnavn,
        tabell,
        kollonen,
        verdien,
        where
      },
      timeout: 5000
    })
      .then(res => {
        this.setState({ navneListe: res.data });
        console.log(res);

        //Render Array
      })
      .catch(err => console.error(err));
  }

  render() {
    return <div>{/*this.renderArray()*/}</div>;
  }
}
